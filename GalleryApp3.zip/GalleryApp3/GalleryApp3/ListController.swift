//
//  ListController.swift
//  GalleryApp3
//
//  Created by tjoeun304 on 2020/03/12.
//  Copyright © 2020 tjoeun304. All rights reserved.
//

import UIKit

/* 갤러리 한건을 담게될 클래스 정의*/

class Gallery:Decodable{
    var gallery_id:Int
    var title:String
    var filename :String
    var regdate : String
    
    init(gallery_id:Int , title:String , filename :String , regdate : String){
        self.gallery_id = gallery_id
        self.title = title
        self.filename = filename
        self.regdate = regdate
    }
}
// 인스턴스를 한개 이상 포함할 클래스 선언

class GalleryList :Decodable {
    var list : [Gallery] = [Gallery]()
}

class ListController: UITableViewController {
    
    var galleryArray : Array<Gallery> =  Array<Gallery>()
    
    
    
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        // 원격지의 url을 통해 json 데이터 가져오기
        
        loadData()
        
    }
    
    func loadData(){
        
        let url = URL(string : "http://localhost:8888/list")
        
        let urlSession = URLSession.shared
        
        // 자바의 람다를. 스위프트 에서는 클로저
        // 클로저의 기본형식은. {(매개변수)-> (반환형) in 코드영역}}
        // 익명함수 : 주로 콜백 함수로 많이 사용
        
        
        
        let task = urlSession.dataTask(with: url!, completionHandler: {(data , respones, error) in
            // json 형태의 데이터를 객체에 담아줌
            let decorder = JSONDecoder()
            
            do{
                var obj = try decorder.decode(GalleryList.self, from: data!)
                
                print("담겨진 개체수는" , obj.list.count)
                
                for gallery in obj.list{
                    self.galleryArray.append(gallery)
                    // UI 변경은 메인 실행부에게 맡기자!!
                    // 서브 실행부가 디자인을 제어할 수없다.
                    // 오직 메인 실행부에게만 주어진 역할 이다.
                    // 메인 실행부에게 데이터를 받은 후 디자인을 다시 요청 한다.
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
            }catch let error{
                print(error)
            }
            // 육안으로 확인하기 위함.
            /*
            let str = String(decoding: data!, as: UTF8.self)
            print("서버에서 받은 데이터는" , str);
            */
        })
        task.resume();
        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return galleryArray.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mycell", for: indexPath)
        var gallery = galleryArray[indexPath.row]
        
    
        cell.textLabel!.text = gallery.title
        
        // Configure the cell...
        var imgURL = URL(string : "http://localhost:8888/data/"+gallery.filename)
        do{
            let imgData = try Data(contentsOf: imgURL!)
            cell.imageView!.image = UIImage(data : imgData)
        }catch {
            print(error)
        }
        
        
        

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
