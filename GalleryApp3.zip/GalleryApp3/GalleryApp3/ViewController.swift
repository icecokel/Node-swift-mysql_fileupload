//
//  ViewController.swift
//  GalleryApp3
//
//  Created by tjoeun304 on 2020/03/12.
//  Copyright © 2020 tjoeun304. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

